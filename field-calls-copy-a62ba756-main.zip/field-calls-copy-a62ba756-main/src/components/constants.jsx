
export const COMPANY_LOGO_URL = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fd977af80678c5e28fba34/4803cfcce_Logo_NameOnly_Horiz_Color.jpg';
