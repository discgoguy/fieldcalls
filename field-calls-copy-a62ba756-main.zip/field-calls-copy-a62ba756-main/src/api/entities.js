import { base44 } from './base44Client';


export const Query = base44.entities.Query;



// auth sdk:
export const User = base44.auth;